package com.spiraldev.cryptoticker.api.models

data class GenericResponse(
    val code: Int,
    val message: String
)
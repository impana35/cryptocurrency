package com.spiraldev.cryptoticker.data.local.database


object DB {
    const val DATABASE_NAME = "Coins.DB"
    const val DATABASE_VERSION = 1
}
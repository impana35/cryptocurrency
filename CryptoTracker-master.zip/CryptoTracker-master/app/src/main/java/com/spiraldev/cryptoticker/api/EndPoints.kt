package com.spiraldev.cryptoticker.api

object EndPoints {
    const val COINS_LIST = "coins/markets"
    const val COINS = "coins/{id}/market_chart"
}